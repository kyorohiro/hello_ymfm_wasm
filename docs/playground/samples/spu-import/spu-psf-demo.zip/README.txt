Original synthetic PS1 sound bank demos. No game code, game samples or recordings.
Data and generator: BSD-3-Clause; see LICENSE.

SPU Synth: PSF / VAB tab. Playground: PS1 mode -> SPU -> Prepare audio.
For VAB, open spu-synth-demo.vab, or select demo.vh and demo.vb together.
For PSF, extract this ZIP, Open PSF folder and choose Demo. Select track.minipsf,
Extract VAB banks, choose a bank/Tone and load it. Use the keyboard to play.
MiniPSF needs all three files in Demo, including the lib subdirectory.
