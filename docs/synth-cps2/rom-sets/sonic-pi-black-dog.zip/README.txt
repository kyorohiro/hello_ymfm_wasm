Tetorica CPS2 Synth - Sonic Pi / The Black Dog kit

In the ROM tab, click Import and select both the .rom and .preset.json files.
In PCM, choose tbd_highkey_c4, tbd_pad_1, tbd_pad_2 or tbd_voctone.
C4 plays each recording at its original speed.
In ADPCM, select Voice 1, 2 and 3 and assign blip, hat and tap respectively.
Play them with A/S/D or 1/2/3.

Source: https://github.com/sonic-pi-net/sonic-pi/tree/stable/etc/samples
All seven samples were donated by The Black Dog under CC0 1.0.
https://creativecommons.org/publicdomain/zero/1.0/
The original filenames appear as the preset names (source extension .flac).
Converted from Playground's local Sonic Pi files to mono signed 8-bit PCM
(22050, 16000, 10000 or 8800 Hz) and QSound ADPCM (approximately 8013 Hz). The PCM loops one silent
byte after its tail so playback cannot spill into the next instrument.
